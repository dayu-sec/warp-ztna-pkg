{{- define "warp-ztna.labels" -}}
app.kubernetes.io/name: warp-ztna
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

